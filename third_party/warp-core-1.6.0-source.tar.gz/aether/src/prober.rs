use std::collections::HashSet;
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr};
use std::sync::atomic::{AtomicU32, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};

use futures::stream::StreamExt;
use rand::Rng;

use crate::error::{AetherError, Result};
use crate::noize::NoizeConfig;
use crate::quic;

pub const MASQUE_DOCUMENTED_CIDRS_V4: &[&str] = &["162.159.197.0/24", "162.159.198.0/24"];

pub const MASQUE_DOH_CIDRS_V4: &[&str] = &["162.159.36.0/24", "162.159.46.0/24"];

pub const MASQUE_CIDRS_V4: &[&str] = &[
    // 162.159.199.0/24 leads: its .1 and .2 answered connect-ip on 4 of 4
    // attempts at 80 ms, the best result of any range measured. This range was
    // missing from the list entirely, so the two most reliable gateways on the
    // fleet were unreachable by seed and by sweep alike.
    "162.159.199.0/24",
    // 162.159.198.0/24 second: .2 and .1 also answer connect-ip, and the account
    // API assigns 162.159.198.2 after a MASQUE key is enrolled.
    "162.159.198.0/24",
    "162.159.197.0/24",
    "162.159.196.0/24",
    "162.159.195.0/24",
    "162.159.192.0/24",
    "162.159.193.0/24",
    "162.159.204.0/24",
    "172.65.251.0/24",
    "188.114.96.0/24",
    "188.114.97.0/24",
    "188.114.98.0/24",
    "188.114.99.0/24",
    "162.159.36.0/24",
    "162.159.46.0/24",
];

/// MASQUE gateway seeds, in dial order.
///
/// Order is measured, not guessed, and the measurement had to be repeated
/// before it was trustworthy. Probed 2026-09-02 from an uncensored host with a
/// **freshly enrolled** device certificate, judging each address only by whether
/// it answered the connect-ip CONNECT, **four attempts each**:
///
/// ```text
/// 162.159.199.1   4/4 :status 200   best 80ms
/// 162.159.199.2   4/4 :status 200   best 87ms
/// 162.159.198.2   3/4 :status 200   best 81ms  (the endpoint the API assigns)
/// 162.159.198.1   2/4 :status 200   best 113ms
/// 162.159.197.1   0/4
/// 162.159.197.2   0/4
/// 162.159.197.3   0/4
/// 162.159.204.2   0/4
/// 162.159.204.3   0/4
/// 162.159.196.1   0/4
/// 162.159.196.2   0/4
/// 162.159.195.1   0/4
/// 162.159.192.1   0/4
/// 162.159.193.1   0/4
/// ```
///
/// Three findings, in order of how much they cost:
///
///   * **One probe is not a verdict.** Every gateway that works missed at least
///     one of four attempts, and `162.159.198.1` missed two. An earlier pass
///     here classified each address from a single sample and wrote off
///     `162.159.199.1` and `.2` — the two best gateways on the fleet — as dead.
///     Anything that ranks these addresses must sample repeatedly.
///   * **162.159.199.0/24 was missing from the codebase entirely**, seeds and
///     CIDR list alike, so its gateways could not be reached by any path.
///   * **"Completes the QUIC handshake" is not evidence of a gateway.** The
///     197.x and 204.x addresses finish QUIC and TLS, then never answer
///     connect-ip. Ranking by handshake is what previously put four addresses
///     that cannot serve MASQUE ahead of ones that can.
///
/// Nothing is deleted: the 0/4 addresses stay reachable through the CIDR sweep
/// and the deep scan. The order just stops spending the user's connect budget
/// on them first.
pub const MASQUE_SEEDS: &[&str] = &[
    "162.159.199.1",
    "162.159.199.2",
    "162.159.198.2",
    "162.159.198.1",
    "162.159.197.1",
    "162.159.204.2",
];

/// The addresses measured answering `:status 200` to connect-ip, best first.
///
/// Kept separate from [`MASQUE_SEEDS`] because the start path needs to know
/// *which* peers are worth a second chance on another UDP port. Retrying an
/// ordinary Cloudflare edge on UDP/500 is pointless — it has no connect-ip
/// listener on any port — while retrying a real gateway there is the only
/// escape from a carrier that degrades UDP/443 to this range specifically.
pub const MASQUE_VERIFIED_GATEWAYS: &[&str] = &[
    "162.159.199.1",
    "162.159.198.1",
    "162.159.199.2",
    "162.159.198.2",
];

pub const MASQUE_PORTS: &[u16] = &[443, 500, 1701, 4500, 4443, 8443, 8095];

/// Alternate UDP ports a verified gateway was measured serving connect-ip on.
///
/// Ordered by field evidence first, then measured hit rate — see the note on
/// 1701 below for why those two disagree.
///
/// Two attempts per (gateway, port) across all four verified gateways with an
/// enrolled certificate, counting only connect-ip `:status 200`:
///
/// ```text
///                :500  :1701  :4500  :8095  :4443  :8443
/// 162.159.199.1   2/2   2/2    2/2    2/2    1/2    1/2
/// 162.159.199.2   1/2   0/2    1/2    2/2    1/2    2/2
/// 162.159.198.2   1/2   2/2    1/2    1/2    2/2    2/2
/// 162.159.198.1   2/2   0/2    1/2    2/2    1/2    1/2
///                ----  ----   ----   ----   ----   ----
///                 6/8   4/8    5/8    7/8    5/8    6/8
/// ```
///
/// Every one of the six ports answers on at least one gateway, which corrects an
/// earlier claim here that 4443 and 8443 complete TLS but never answer
/// connect-ip. That claim came from a single-sample run — the same mistake that
/// mis-ranked the seed list. 4443 and 8443 are still left out of the start-path
/// ladder to hold the connect budget at four rungs, and the sweep still reaches
/// them through [`MASQUE_PORTS`].
///
/// This run measured hit rate only, not latency. The earlier single-sample pass
/// timed 500/1701/4500/8095 at 86–129 ms, the same class as 443, which is what
/// the design argument below rests on: it is the same gateway and the same
/// HTTP/3 data plane, so the alternate port costs nothing but the dial.
///
/// 1701 leads despite ranking last on total hits, because the spread above is
/// sampling noise on an uncensored path — no port here is actually unreachable
/// from a VPS — and it says nothing about which port survives Iranian DPI. 1701
/// is the only one with field evidence: it is where WireGuard-over-WARP
/// connected from inside Iran while UDP/443 was being dropped. Field evidence
/// outranks VPS hit rate for ordering.
///
/// Caveat worth knowing before trusting a rung: 1701 answered 2/2 on
/// `162.159.199.1` and `162.159.198.2` but 0/2 on `162.159.199.2` and
/// `162.159.198.1`, and the ladder pairs each port with the first two verified
/// gateways. So the 1701 pair is one measured-good rung followed by one
/// measured-dead rung. Left as is because per-port gateway tables in a const are
/// worse than one wasted 5 s dial, but if the ladder ever needs shortening, that
/// rung is the first to cut.
///
/// This is why the escape from a blocked UDP/443 belongs here and not in the
/// HTTP/2 pass: another UDP port on the same gateway keeps QUIC, keeps the
/// throughput, and is known to work. HTTP/2 over TCP is not served connect-ip
/// by any public Cloudflare edge at all.
pub const MASQUE_ALT_PORTS: &[u16] = &[1701, 8095, 500, 4500];

pub const MASQUE_CIDRS_V6: &[&str] = &[
    // WARP's own IPv6 MASQUE range (the WARP client's log names
    // [2606:4700:103::1]); upstream aether 3aae45d / 7c39a61 found regular
    // WARP answers MASQUE over IPv6 here. Leads for non-team WARP; with a team,
    // `prioritize` still moves 2606:4700:102::/48 first.
    "2606:4700:103::/48",
    "2606:4700:d0::/48",
    "2606:4700:102::/48",
    "2606:4700:d1::/48",
];

pub const MASQUE_ZT_CIDRS_V4: &[&str] = &["162.159.197.0/24"];

pub const MASQUE_ZT_CIDRS_V6: &[&str] = &["2606:4700:102::/48"];

pub fn zero_trust_mode() -> bool {
    std::env::var("AETHER_TEAM")
        .map(|value| !value.trim().is_empty())
        .unwrap_or(false)
}

pub fn prioritize(all: &[&'static str], first: &[&'static str]) -> Vec<&'static str> {
    if !zero_trust_mode() {
        return all.to_vec();
    }

    let mut out: Vec<&'static str> = Vec::with_capacity(all.len());
    for entry in first {
        if all.contains(entry) {
            out.push(entry);
        }
    }
    for entry in all {
        if !out.contains(entry) {
            out.push(entry);
        }
    }
    out
}

pub fn masque_cidrs_v4() -> Vec<&'static str> {
    prioritize(MASQUE_CIDRS_V4, MASQUE_ZT_CIDRS_V4)
}

pub fn masque_cidrs_v6() -> Vec<&'static str> {
    prioritize(MASQUE_CIDRS_V6, MASQUE_ZT_CIDRS_V6)
}

pub const MASQUE_SEEDS_V6: &[&str] = &[
    // WARP's own IPv6 MASQUE gateway. The range sampler puts an IPv4 tail in
    // the last 32 bits, so ::1 is only ever reached as a seed.
    "2606:4700:103::1",
    "2606:4700:d0::a29f:c602",
    "2606:4700:d1::a29f:c602",
    "2606:4700:d0::a29f:c601",
    "2606:4700:d0::a29f:c001",
];

/// Last-resort IPv4 MASQUE gateways from upstream aether (42be629, 8ced710):
/// the addresses of 162.159.198.0/24 (75) and then 162.159.199.0/24 (222) that
/// completed a TCP handshake on port 443 from upstream's network, each range
/// fastest first as upstream measured it. They are queued only after this
/// core's own seeds, port ladder and CIDR sweep, each on every MASQUE port,
/// and only without a team. Nothing here replaces or reorders
/// [`MASQUE_SEEDS`]; 162.159.199.2-.33, which upstream drops, stay reachable
/// through the seeds and the sweep.
pub const MASQUE_UPSTREAM_FALLBACK_V4: &[&str] = &[
    "162.159.198.183", "162.159.198.206", "162.159.198.226", "162.159.198.125",
    "162.159.198.72", "162.159.198.89", "162.159.198.198", "162.159.198.131",
    "162.159.198.245", "162.159.198.114", "162.159.198.31", "162.159.198.60",
    "162.159.198.4", "162.159.198.65", "162.159.198.33", "162.159.198.86",
    "162.159.198.244", "162.159.198.123", "162.159.198.233", "162.159.198.69",
    "162.159.198.255", "162.159.198.176", "162.159.198.186", "162.159.198.63",
    "162.159.198.37", "162.159.198.169", "162.159.198.147", "162.159.198.120",
    "162.159.198.135", "162.159.198.54", "162.159.198.234", "162.159.198.109",
    "162.159.198.175", "162.159.198.231", "162.159.198.219", "162.159.198.216",
    "162.159.198.64", "162.159.198.250", "162.159.198.184", "162.159.198.74",
    "162.159.198.241", "162.159.198.213", "162.159.198.232", "162.159.198.75",
    "162.159.198.77", "162.159.198.172", "162.159.198.145", "162.159.198.36",
    "162.159.198.124", "162.159.198.80", "162.159.198.192", "162.159.198.82",
    "162.159.198.137", "162.159.198.141", "162.159.198.48", "162.159.198.71",
    "162.159.198.227", "162.159.198.207", "162.159.198.49", "162.159.198.178",
    "162.159.198.197", "162.159.198.203", "162.159.198.204", "162.159.198.205",
    "162.159.198.195", "162.159.198.230", "162.159.198.202", "162.159.198.53",
    "162.159.198.79", "162.159.198.58", "162.159.198.35", "162.159.198.239",
    "162.159.198.116", "162.159.198.127", "162.159.198.240", "162.159.199.87",
    "162.159.199.117", "162.159.199.48", "162.159.199.217", "162.159.199.65",
    "162.159.199.198", "162.159.199.47", "162.159.199.103", "162.159.199.133",
    "162.159.199.151", "162.159.199.195", "162.159.199.73", "162.159.199.156",
    "162.159.199.247", "162.159.199.127", "162.159.199.158", "162.159.199.208",
    "162.159.199.82", "162.159.199.213", "162.159.199.70", "162.159.199.243",
    "162.159.199.204", "162.159.199.154", "162.159.199.240", "162.159.199.236",
    "162.159.199.126", "162.159.199.186", "162.159.199.188", "162.159.199.187",
    "162.159.199.124", "162.159.199.43", "162.159.199.102", "162.159.199.60",
    "162.159.199.219", "162.159.199.163", "162.159.199.193", "162.159.199.135",
    "162.159.199.110", "162.159.199.94", "162.159.199.136", "162.159.199.233",
    "162.159.199.77", "162.159.199.241", "162.159.199.223", "162.159.199.120",
    "162.159.199.38", "162.159.199.75", "162.159.199.57", "162.159.199.118",
    "162.159.199.50", "162.159.199.76", "162.159.199.58", "162.159.199.145",
    "162.159.199.81", "162.159.199.54", "162.159.199.234", "162.159.199.157",
    "162.159.199.121", "162.159.199.246", "162.159.199.182", "162.159.199.1",
    "162.159.199.251", "162.159.199.35", "162.159.199.179", "162.159.199.147",
    "162.159.199.137", "162.159.199.49", "162.159.199.138", "162.159.199.116",
    "162.159.199.172", "162.159.199.42", "162.159.199.160", "162.159.199.88",
    "162.159.199.212", "162.159.199.174", "162.159.199.79", "162.159.199.105",
    "162.159.199.130", "162.159.199.252", "162.159.199.238", "162.159.199.248",
    "162.159.199.125", "162.159.199.62", "162.159.199.34", "162.159.199.239",
    "162.159.199.84", "162.159.199.104", "162.159.199.196", "162.159.199.72",
    "162.159.199.97", "162.159.199.74", "162.159.199.229", "162.159.199.159",
    "162.159.199.192", "162.159.199.201", "162.159.199.44", "162.159.199.222",
    "162.159.199.142", "162.159.199.78", "162.159.199.235", "162.159.199.168",
    "162.159.199.162", "162.159.199.39", "162.159.199.209", "162.159.199.111",
    "162.159.199.139", "162.159.199.113", "162.159.199.215", "162.159.199.245",
    "162.159.199.86", "162.159.199.46", "162.159.199.180", "162.159.199.66",
    "162.159.199.173", "162.159.199.53", "162.159.199.216", "162.159.199.237",
    "162.159.199.114", "162.159.199.109", "162.159.199.214", "162.159.199.190",
    "162.159.199.106", "162.159.199.100", "162.159.199.92", "162.159.199.96",
    "162.159.199.61", "162.159.199.108", "162.159.199.64", "162.159.199.101",
    "162.159.199.140", "162.159.199.123", "162.159.199.112", "162.159.199.199",
    "162.159.199.225", "162.159.199.83", "162.159.199.69", "162.159.199.90",
    "162.159.199.153", "162.159.199.115", "162.159.199.149", "162.159.199.36",
    "162.159.199.224", "162.159.199.155", "162.159.199.37", "162.159.199.52",
    "162.159.199.63", "162.159.199.164", "162.159.199.253", "162.159.199.141",
    "162.159.199.242", "162.159.199.89", "162.159.199.67", "162.159.199.185",
    "162.159.199.98", "162.159.199.167", "162.159.199.0", "162.159.199.176",
    "162.159.199.189", "162.159.199.218", "162.159.199.211", "162.159.199.221",
    "162.159.199.220", "162.159.199.231", "162.159.199.230", "162.159.199.206",
    "162.159.199.175", "162.159.199.184", "162.159.199.203", "162.159.199.255",
    "162.159.199.171", "162.159.199.45", "162.159.199.228", "162.159.199.177",
    "162.159.199.165", "162.159.199.122", "162.159.199.99", "162.159.199.183",
    "162.159.199.161", "162.159.199.144", "162.159.199.119", "162.159.199.128",
    "162.159.199.146", "162.159.199.148", "162.159.199.68", "162.159.199.56",
    "162.159.199.95", "162.159.199.55", "162.159.199.197", "162.159.199.41",
    "162.159.199.194", "162.159.199.226", "162.159.199.134", "162.159.199.249",
    "162.159.199.232", "162.159.199.227", "162.159.199.191", "162.159.199.150",
    "162.159.199.170", "162.159.199.202", "162.159.199.169", "162.159.199.207",
    "162.159.199.166", "162.159.199.250", "162.159.199.210", "162.159.199.181",
    "162.159.199.132", "162.159.199.129", "162.159.199.107", "162.159.199.71",
    "162.159.199.152", "162.159.199.91", "162.159.199.131", "162.159.199.205",
    "162.159.199.85", "162.159.199.59", "162.159.199.51", "162.159.199.143",
    "162.159.199.244", "162.159.199.254", "162.159.199.178", "162.159.199.200",
    "162.159.199.93",
];

#[derive(Debug, Clone, Copy)]
pub struct ProbeResult {
    pub ip: IpAddr,
    pub port: u16,
    pub rtt: Duration,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum IpScan {
    V4,
    V6,
    Both,
}

impl IpScan {
    pub fn parse(s: &str) -> IpScan {
        match s.trim().to_lowercase().as_str() {
            "6" | "v6" | "ipv6" => IpScan::V6,
            "both" | "all" | "dual" => IpScan::Both,
            _ => IpScan::V4,
        }
    }

    pub fn label(&self) -> &'static str {
        match self {
            IpScan::V4 => "ipv4",
            IpScan::V6 => "ipv6",
            IpScan::Both => "dual-stack",
        }
    }

    pub fn want_v4(&self) -> bool {
        matches!(self, IpScan::V4 | IpScan::Both)
    }

    pub fn want_v6(&self) -> bool {
        matches!(self, IpScan::V6 | IpScan::Both)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ScanMode {
    Turbo,
    Balanced,
    Thorough,
    Stealth,
    Ironclad,
}

impl ScanMode {
    pub fn parse(s: &str) -> ScanMode {
        match s.trim().to_lowercase().as_str() {
            "turbo" | "fast" => ScanMode::Turbo,
            "thorough" | "deep" | "pro" => ScanMode::Thorough,
            "stealth" | "quiet" => ScanMode::Stealth,
            "ironclad" | "real" | "verify" | "guaranteed" => ScanMode::Ironclad,
            _ => ScanMode::Balanced,
        }
    }

    pub fn label(&self) -> &'static str {
        match self {
            ScanMode::Turbo => "turbo",
            ScanMode::Balanced => "balanced",
            ScanMode::Thorough => "thorough",
            ScanMode::Stealth => "stealth",
            ScanMode::Ironclad => "ironclad",
        }
    }

    fn strategy(&self) -> Strategy {
        match self {
            ScanMode::Turbo => Strategy {
                concurrency: 20,
                per_probe_timeout: Duration::from_millis(6000),
                overall_deadline: Duration::from_secs(18),
                quiet_after_first: Duration::from_secs(0),
                target_successes: 1,
                early_exit_first: true,
                full_subnet: false,
                sample_per_cidr: 64,
            },
            ScanMode::Balanced => Strategy {
                concurrency: 16,
                per_probe_timeout: Duration::from_millis(6000),
                overall_deadline: Duration::from_secs(25),
                quiet_after_first: Duration::from_secs(2),
                target_successes: 3,
                early_exit_first: false,
                full_subnet: false,
                sample_per_cidr: 80,
            },
            ScanMode::Thorough => Strategy {
                concurrency: 18,
                per_probe_timeout: Duration::from_millis(8000),
                overall_deadline: Duration::from_secs(45),
                quiet_after_first: Duration::from_secs(6),
                target_successes: 5,
                early_exit_first: false,
                full_subnet: false,
                sample_per_cidr: 180,
            },
            ScanMode::Stealth => Strategy {
                concurrency: 3,
                per_probe_timeout: Duration::from_millis(12000),
                overall_deadline: Duration::from_secs(180),
                quiet_after_first: Duration::from_secs(25),
                target_successes: 4,
                early_exit_first: false,
                full_subnet: false,
                sample_per_cidr: 64,
            },
            ScanMode::Ironclad => Strategy {
                concurrency: 4,
                per_probe_timeout: Duration::from_millis(15000),
                overall_deadline: Duration::from_secs(180),
                quiet_after_first: Duration::from_secs(15),
                target_successes: 3,
                early_exit_first: false,
                full_subnet: false,
                sample_per_cidr: 140,
            },
        }
    }
}

const IRONCLAD_TCPING_TIMEOUT: Duration = Duration::from_secs(10);

struct Strategy {
    concurrency: usize,
    per_probe_timeout: Duration,
    overall_deadline: Duration,
    quiet_after_first: Duration,
    target_successes: usize,
    early_exit_first: bool,
    full_subnet: bool,
    sample_per_cidr: usize,
}

#[derive(Clone)]
pub struct MasqueProbe {
    pub sni: String,
    pub authority: String,
    pub path: String,
    pub cert_pem: Arc<[u8]>,
    pub key_pem: Arc<[u8]>,
    pub ech_config_list: Option<Arc<[u8]>>,
    pub noize: NoizeConfig,
    pub tls_curve_preset: crate::TlsCurvePreset,
    pub ports: Vec<u16>,
    pub ip: IpScan,
    pub local_ipv4: Ipv4Addr,
}

pub async fn host_has_ipv6() -> bool {
    match tokio::net::UdpSocket::bind("[::]:0").await {
        Ok(sock) => {
            if crate::platform::protect_socket(&sock).is_err() {
                return false;
            }
            sock.connect("[2606:4700:d0::a29f:c001]:443").await.is_ok()
        }
        Err(_) => false,
    }
}

static PROBE_IDENTITY_REJECTIONS: AtomicU32 = AtomicU32::new(0);

pub fn reset_identity_rejections() {
    PROBE_IDENTITY_REJECTIONS.store(0, Ordering::Relaxed);
}

pub fn identity_rejections() -> u32 {
    PROBE_IDENTITY_REJECTIONS.load(Ordering::Relaxed)
}

/// Count a probe that refused the device certificate. Timeouts and HTTP 400
/// do not count: those say nothing about the certificate.
pub fn note_probe_failure(error: &str) {
    let refused = error.contains("TLSV1_ALERT_ACCESS_DENIED")
        || error.contains("connect-ip status 401")
        || error.contains("connect-ip status 403")
        || (error.contains("TLS alert 49") && error.contains(quic::CONNECT_STAGE_AFTER_REQUEST));
    if refused {
        PROBE_IDENTITY_REJECTIONS.fetch_add(1, Ordering::Relaxed);
    }
}

pub async fn hunt_best_gateway(probe: &MasqueProbe, mode: ScanMode) -> Result<ProbeResult> {
    reset_identity_rejections();
    let mut st = mode.strategy();
    st.concurrency = crate::sysprofile::cap_concurrency(st.concurrency);
    let timeout = st.per_probe_timeout;
    let mut effective_ip = probe.ip;
    if probe.ip.want_v6() && !host_has_ipv6().await {
        if probe.ip.want_v4() {
            log::warn!("[-] host has no IPv6 route; falling back to IPv4-only scan");
            crate::ffi::record_log("MASQUE: IPv6 fallback: no IPv6 route on this network; scanning IPv4 only");
        } else {
            log::warn!("[-] host has no IPv6 route; IPv6 picked, scanning IPv4 instead");
            crate::ffi::record_log("MASQUE: IPv6 fallback: IPv6 picked but this network has no IPv6 route; scanning IPv4 instead");
        }
        effective_ip = IpScan::V4;
    }
    let candidates = build_candidates(&st, &probe.ports, effective_ip);

    log::info!(
        "[*] scan mode={} ip={} candidates={} ports={:?} concurrency={} per_probe={:?} budget={:?}",
        mode.label(),
        effective_ip.label(),
        candidates.len(),
        probe.ports,
        st.concurrency,
        st.per_probe_timeout,
        st.overall_deadline,
    );

    let ironclad = mode == ScanMode::Ironclad;

    let stream = futures::stream::iter(
        candidates
            .into_iter()
            .map(|(ip, port)| verify_one(probe, ip, port, timeout, ironclad)),
    )
    .buffer_unordered(st.concurrency);
    tokio::pin!(stream);

    let deadline = Instant::now() + st.overall_deadline;
    let mut best: Option<ProbeResult> = None;
    let mut found = 0usize;
    let mut quiet_until: Option<Instant> = None;

    loop {
        let effective = match quiet_until {
            Some(q) => q.min(deadline),
            None => deadline,
        };
        let remaining = effective.saturating_duration_since(Instant::now());
        if remaining.is_zero() {
            if best.is_some() {
                if quiet_until.is_some() {
                    log::info!("[+] no new gateways recently, finalizing selection");
                } else {
                    log::warn!("[-] scan deadline reached");
                }
            } else {
                log::warn!("[-] scan deadline reached with no gateway");
            }
            break;
        }

        tokio::select! {
            item = stream.next() => {
                match item {
                    None => break,
                    Some(None) => {
                        if best.is_none() && identity_rejections() >= 2 {
                            crate::ffi::record_log(
                                "Certificate refused during the scan. Stopping this sweep to request a new certificate.",
                            );
                            break;
                        }
                        continue;
                    }
                    Some(Some(pr)) => {
                        log::info!("[+] candidate ok {}:{} rtt={:?}", pr.ip, pr.port, pr.rtt);
                        if st.early_exit_first {
                            return Ok(pr);
                        }
                        best = Some(match best {
                            Some(cur) if cur.rtt <= pr.rtt => cur,
                            _ => pr,
                        });
                        found += 1;
                        if quiet_until.is_none() && !st.quiet_after_first.is_zero() {
                            quiet_until = Some(Instant::now() + st.quiet_after_first);
                            log::info!(
                                "[+] first gateway in {:?}; ranking for {:?}",
                                pr.rtt,
                                st.quiet_after_first
                            );
                        }
                        if st.target_successes > 0 && found >= st.target_successes {
                            log::info!(
                                "[+] reached target of {} gateways, selecting best",
                                st.target_successes
                            );
                            break;
                        }
                    }
                }
            }
            _ = tokio::time::sleep(remaining) => {
                if best.is_some() {
                    if quiet_until.is_some() {
                        log::info!("[+] no new gateways recently, finalizing selection");
                    } else {
                        log::warn!("[-] scan deadline reached");
                    }
                } else {
                    log::warn!("[-] scan deadline reached with no gateway");
                }
                break;
            }
        }
    }

    match best {
        Some(pr) => {
            log::info!("[+] best gateway {}:{} rtt={:?}", pr.ip, pr.port, pr.rtt);
            Ok(pr)
        }
        None => Err(AetherError::NoCleanEndpoint),
    }
}

pub async fn verify_cached_gateways(
    probe: &MasqueProbe,
    gateways: Vec<SocketAddr>,
) -> Option<ProbeResult> {
    let stream = futures::stream::iter(gateways.into_iter().map(|gateway| {
        verify_one(
            probe,
            gateway.ip(),
            gateway.port(),
            Duration::from_secs(6),
            false,
        )
    }))
    .buffer_unordered(3);
    tokio::pin!(stream);

    while let Some(result) = stream.next().await {
        if result.is_some() {
            return result;
        }
    }
    None
}

async fn verify_one(
    probe: &MasqueProbe,
    ip: IpAddr,
    port: u16,
    timeout: Duration,
    ironclad: bool,
) -> Option<ProbeResult> {
    if ironclad {
        let params = crate::tunnelping::MasquePingParams {
            peer: SocketAddr::new(ip, port),
            sni: probe.sni.clone(),
            authority: probe.authority.clone(),
            path: probe.path.clone(),
            cert_pem: probe.cert_pem.to_vec(),
            key_pem: probe.key_pem.to_vec(),
            noize: probe.noize.clone(),
            local_ipv4: probe.local_ipv4,
            local_ipv4_str: probe.local_ipv4.to_string(),
            local_ipv6_str: String::new(),
        };
        return match crate::tunnelping::masque_http_ping(&params, IRONCLAD_TCPING_TIMEOUT).await {
            Ok(rtt) => {
                log::info!(
                    "[+] ironclad verified {ip}:{port} real http round trip rtt={:?}",
                    rtt
                );
                Some(ProbeResult { ip, port, rtt })
            }
            Err(e) => {
                log::trace!("[-] ironclad {ip}:{port} failed real http check: {e}");
                None
            }
        };
    }

    let transport = if crate::masque_h2::enabled() {
        "HTTP/2"
    } else {
        "HTTP/3"
    };
    crate::ffi::record_log(format!("Scanning {ip}:{port} via {transport}"));
    if crate::masque_h2::enabled() {
        let cfg = crate::masque_h2::H2TunnelConfig {
            peer: SocketAddr::new(ip, port),
            sni: crate::consts::L4_CONNECT_SNI.to_string(),
            authority: probe.authority.clone(),
            path: probe.path.clone(),
            cert_pem: probe.cert_pem.to_vec(),
            key_pem: probe.key_pem.to_vec(),
            local_ipv4: probe.local_ipv4,
            quiet: true,
            pin_endpoint: false,
            expected_pins: Vec::new(),
        };
        return match crate::masque_h2::verify_h2(&cfg, timeout).await {
            Ok(rtt) => {
                crate::ffi::record_log(format!("Accepted {ip}:{port} ({rtt:?})"));
                Some(ProbeResult { ip, port, rtt })
            }
            Err(e) => {
                note_probe_failure(&e.to_string());
                crate::ffi::record_log(format!("Rejected {ip}:{port}: {e}"));
                log::trace!("h2 probe {ip}:{port} -> {e}");
                None
            }
        };
    }

    let vp = quic::VerifyParams {
        peer: SocketAddr::new(ip, port),
        sni: probe.sni.clone(),
        authority: probe.authority.clone(),
        path: probe.path.clone(),
        cert_pem: probe.cert_pem.to_vec(),
        key_pem: probe.key_pem.to_vec(),
        ech_config_list: probe.ech_config_list.as_ref().map(|a| a.to_vec()),
        noize: probe.noize.clone(),
        tls_curve_preset: probe.tls_curve_preset,
        timeout,
        local_ipv4: probe.local_ipv4,
    };

    let verify = async {
        let rtt = quic::verify_masque(&vp).await?;
        if ironclad {
            quic::verify_masque(&vp).await?;
        }
        Ok::<_, AetherError>(rtt)
    };

    match tokio::time::timeout(timeout, verify).await {
        Ok(Ok(rtt)) => {
            crate::ffi::record_log(format!("Accepted {ip}:{port} ({rtt:?})"));
            Some(ProbeResult { ip, port, rtt })
        }
        Ok(Err(e)) => {
            note_probe_failure(&e.to_string());
            crate::ffi::record_log(format!("Rejected {ip}:{port}: {e}"));
            log::debug!("probe {ip}:{port} -> {e}");
            None
        }
        Err(_) => {
            crate::ffi::record_log(format!("Rejected {ip}:{port}: probe timeout"));
            log::debug!("probe {ip}:{port} timed out; probe future dropped");
            None
        }
    }
}

fn build_candidates(st: &Strategy, ports: &[u16], ip: IpScan) -> Vec<(IpAddr, u16)> {
    let primary = ports.first().copied().unwrap_or(443);
    let mut out: Vec<(IpAddr, u16)> = Vec::new();
    let mut seen: HashSet<(IpAddr, u16)> = HashSet::new();

    let seeds: Vec<Ipv4Addr> = MASQUE_SEEDS.iter().filter_map(|s| s.parse().ok()).collect();
    let seeds6: Vec<Ipv6Addr> = MASQUE_SEEDS_V6
        .iter()
        .filter_map(|s| s.parse().ok())
        .collect();

    // Seeds on the primary port, then the same seeds on every alternate port,
    // and only then the wide CIDR sweep.
    //
    // The alternate ports used to sit at the very end of the queue, behind
    // thousands of addresses on 443. A carrier that drops UDP/443 but leaves
    // UDP/500 and UDP/4500 alone therefore never reached them: the 120 s scan
    // deadline expired mid-sweep. A field log from Irancell showed 4433 probes
    // across 2735 addresses without a single non-443 port being tried, while
    // WireGuard — which starts at 2408 — connected immediately on the same SIM.
    //
    // Eight seeds times six alternate ports is 48 extra probes at concurrency
    // 16-20, so a network where 443 works still selects a gateway from the
    // first batch and never pays for them.
    if ip.want_v4() {
        for a in &seeds {
            if seen.insert((IpAddr::V4(*a), primary)) {
                out.push((IpAddr::V4(*a), primary));
            }
        }
    }
    if ip.want_v6() {
        for a in &seeds6 {
            if seen.insert((IpAddr::V6(*a), primary)) {
                out.push((IpAddr::V6(*a), primary));
            }
        }
    }

    if ip.want_v4() {
        for a in &seeds {
            for &port in ports {
                if port != primary && seen.insert((IpAddr::V4(*a), port)) {
                    out.push((IpAddr::V4(*a), port));
                }
            }
        }
    }
    if ip.want_v6() {
        for a in &seeds6 {
            for &port in ports {
                if port != primary && seen.insert((IpAddr::V6(*a), port)) {
                    out.push((IpAddr::V6(*a), port));
                }
            }
        }
    }

    if ip.want_v4() {
        let cidr_hosts: Vec<Vec<Ipv4Addr>> = masque_cidrs_v4()
            .iter()
            .map(|c| {
                if st.full_subnet {
                    enumerate_cidr_v4(c)
                } else {
                    sample_cidr_v4(c, st.sample_per_cidr)
                }
            })
            .collect();
        let max_len = cidr_hosts.iter().map(|v| v.len()).max().unwrap_or(0);
        for i in 0..max_len {
            for hosts in &cidr_hosts {
                if let Some(a) = hosts.get(i) {
                    if seen.insert((IpAddr::V4(*a), primary)) {
                        out.push((IpAddr::V4(*a), primary));
                    }
                }
            }
        }
    }

    if ip.want_v6() {
        let per = if st.sample_per_cidr == 0 {
            96
        } else {
            st.sample_per_cidr
        };
        let cidr6: Vec<Vec<Ipv6Addr>> = masque_cidrs_v6()
            .iter()
            .map(|c| sample_cidr_v6(c, per, MASQUE_CIDRS_V4))
            .collect();
        let max6 = cidr6.iter().map(|v| v.len()).max().unwrap_or(0);
        for i in 0..max6 {
            for hosts in &cidr6 {
                if let Some(a) = hosts.get(i) {
                    if seen.insert((IpAddr::V6(*a), primary)) {
                        out.push((IpAddr::V6(*a), primary));
                    }
                }
            }
        }
    }

    // Last fallback: upstream's measured gateways on every port, after
    // everything above (seeds, port ladder, sweeps). The deadline usually ends
    // the scan long before this, so a network where the own list works never
    // pays for it. Pairs already queued are skipped.
    if ip.want_v4() && !zero_trust_mode() {
        let fallback: Vec<Ipv4Addr> = MASQUE_UPSTREAM_FALLBACK_V4
            .iter()
            .filter_map(|s| s.parse().ok())
            .collect();
        for a in &fallback {
            for &port in ports {
                if seen.insert((IpAddr::V4(*a), port)) {
                    out.push((IpAddr::V4(*a), port));
                }
            }
        }
    }

    out
}

fn parse_cidr_v4(cidr: &str) -> Option<(u32, u8)> {
    let (ip, prefix) = cidr.split_once('/')?;
    Some((
        u32::from(ip.parse::<Ipv4Addr>().ok()?),
        prefix.parse().ok()?,
    ))
}

fn enumerate_cidr_v4(cidr: &str) -> Vec<Ipv4Addr> {
    let (base, prefix) = match parse_cidr_v4(cidr) {
        Some(v) => v,
        None => return Vec::new(),
    };
    let host_bits = 32u32.saturating_sub(prefix as u32);
    if host_bits == 0 {
        return vec![Ipv4Addr::from(base)];
    }
    if host_bits > 12 {
        return Vec::new();
    }
    let size = 1u32 << host_bits;
    (1..size.saturating_sub(1))
        .map(|off| Ipv4Addr::from(base + off))
        .collect()
}

fn sample_cidr_v4(cidr: &str, n: usize) -> Vec<Ipv4Addr> {
    let (base, prefix) = match parse_cidr_v4(cidr) {
        Some(v) => v,
        None => return Vec::new(),
    };
    let host_bits = 32u32.saturating_sub(prefix as u32);
    let size = if host_bits >= 32 {
        u32::MAX
    } else {
        1u32 << host_bits
    };
    if size <= 2 {
        return vec![Ipv4Addr::from(base)];
    }

    let usable = size - 2;
    let want = (n as u32).min(usable);
    let mut rng = rand::thread_rng();
    let mut chosen: HashSet<u32> = HashSet::with_capacity(want as usize);
    let mut out = Vec::with_capacity(want as usize);

    while (out.len() as u32) < want {
        let off = 1 + rng.gen_range(0..usable);
        if chosen.insert(off) {
            out.push(Ipv4Addr::from(base + off));
        }
    }

    out
}

fn parse_cidr_v6(cidr: &str) -> Option<(u128, u8)> {
    let (ip, prefix) = cidr.split_once('/')?;
    Some((
        u128::from(ip.parse::<Ipv6Addr>().ok()?),
        prefix.parse().ok()?,
    ))
}

fn sample_cidr_v6(cidr: &str, n: usize, v4_cidrs: &[&str]) -> Vec<Ipv6Addr> {
    let (base, prefix) = match parse_cidr_v6(cidr) {
        Some(v) => v,
        None => return Vec::new(),
    };
    if 128u32.saturating_sub(prefix as u32) == 0 {
        return vec![Ipv6Addr::from(base)];
    }

    let v4: Vec<(u32, u8)> = v4_cidrs.iter().filter_map(|c| parse_cidr_v4(c)).collect();
    let mut rng = rand::thread_rng();
    let mut out = Vec::with_capacity(n);
    for _ in 0..n {
        let embedded = if v4.is_empty() {
            rng.gen::<u32>() as u128
        } else {
            let (b, p) = v4[rng.gen_range(0..v4.len())];
            let host_bits = 32u32.saturating_sub(p as u32);
            let host = if host_bits == 0 {
                0
            } else {
                rng.gen::<u32>() & ((1u32 << host_bits) - 1)
            };
            (b | host) as u128
        };
        out.push(Ipv6Addr::from(base | embedded));
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_documented_zero_trust_masque_ingress_range_is_scanned() {
        assert!(MASQUE_CIDRS_V4.contains(&"162.159.197.0/24"));
        assert!(MASQUE_CIDRS_V6.contains(&"2606:4700:102::/48"));
    }

    #[test]
    fn the_dns_over_https_ranges_are_swept_last_because_they_never_serve_masque() {
        let tail = &MASQUE_CIDRS_V4[MASQUE_CIDRS_V4.len() - MASQUE_DOH_CIDRS_V4.len()..];
        for entry in MASQUE_DOH_CIDRS_V4 {
            assert!(tail.contains(entry), "{entry} should be at the end");
        }
    }

    #[test]
    fn connect_scan_modes_finish_fast_enough_for_android() {
        let turbo = ScanMode::Turbo.strategy();
        let balanced = ScanMode::Balanced.strategy();
        let thorough = ScanMode::Thorough.strategy();

        assert!(turbo.early_exit_first);
        assert!(!balanced.early_exit_first);
        assert!(!thorough.early_exit_first);
        assert!(!thorough.full_subnet);
        assert!(balanced.quiet_after_first <= Duration::from_secs(3));
        assert!(thorough.quiet_after_first <= Duration::from_secs(8));
        assert!(balanced.overall_deadline <= Duration::from_secs(30));
        assert!(thorough.overall_deadline <= Duration::from_secs(50));
        assert!(turbo.overall_deadline <= balanced.overall_deadline);
        assert!(balanced.overall_deadline <= thorough.overall_deadline);
        assert!(balanced.target_successes >= 1 && balanced.target_successes <= 3);
        assert!(thorough.sample_per_cidr > balanced.sample_per_cidr);
    }

    #[test]
    fn the_documented_default_masque_port_leads_the_sweep() {
        assert_eq!(MASQUE_PORTS.first(), Some(&443));
    }

    #[test]
    fn the_documented_masque_fallback_ports_keep_their_documented_order() {
        assert_eq!(MASQUE_PORTS, &[443, 500, 1701, 4500, 4443, 8443, 8095]);
    }

    #[test]
    fn every_seed_is_tried_on_every_alternate_port_before_the_cidr_sweep() {
        let st = ScanMode::Balanced.strategy();
        let candidates = build_candidates(&st, MASQUE_PORTS, IpScan::V4);
        let seeds: Vec<Ipv4Addr> = MASQUE_SEEDS.iter().filter_map(|s| s.parse().ok()).collect();

        // The head of the queue is the seeds on 443, then the seeds on the
        // alternate ports. Nothing from the wide sweep may come before them.
        let head = seeds.len() * MASQUE_PORTS.len();
        assert!(candidates.len() > head, "the sweep should still be there");
        for (i, (ip, port)) in candidates.iter().take(head).enumerate() {
            let ip = match ip {
                IpAddr::V4(v4) => *v4,
                IpAddr::V6(_) => panic!("v4-only scan produced a v6 candidate at {i}"),
            };
            assert!(seeds.contains(&ip), "{ip}:{port} at {i} is not a seed");
        }
        for &port in MASQUE_PORTS {
            for seed in &seeds {
                let want = (IpAddr::V4(*seed), port);
                let at = candidates.iter().position(|c| *c == want);
                assert!(at.is_some_and(|at| at < head), "{seed}:{port} is not early");
            }
        }
    }

    #[test]
    fn the_primary_port_still_wins_the_very_first_probes() {
        // A network where UDP/443 works must not pay for the alternate ports:
        // the first batch the scanner dispatches is still seeds on 443.
        let st = ScanMode::Balanced.strategy();
        let candidates = build_candidates(&st, MASQUE_PORTS, IpScan::V4);
        let seeds = MASQUE_SEEDS.len();
        for (ip, port) in candidates.iter().take(seeds) {
            assert_eq!(*port, 443, "{ip}:{port} should be on the primary port");
        }
    }

    #[test]
    fn the_cidr_sweep_only_ever_uses_the_primary_port() {
        let st = ScanMode::Balanced.strategy();
        let candidates = build_candidates(&st, MASQUE_PORTS, IpScan::V4);
        let seeds: Vec<Ipv4Addr> = MASQUE_SEEDS.iter().filter_map(|s| s.parse().ok()).collect();
        let fallback: Vec<Ipv4Addr> = MASQUE_UPSTREAM_FALLBACK_V4
            .iter()
            .filter_map(|s| s.parse().ok())
            .collect();
        // The sweep itself ends where the upstream fallback tail begins.
        let tail_start = candidates
            .iter()
            .position(|(ip, port)| {
                matches!(ip, IpAddr::V4(v4) if fallback.contains(v4) && !seeds.contains(v4))
                    && *port != 443
            })
            .unwrap_or(candidates.len());
        for (ip, port) in &candidates[..tail_start] {
            let IpAddr::V4(v4) = ip else { continue };
            if !seeds.contains(v4) {
                assert_eq!(*port, 443, "swept {ip} on {port}, which multiplies the scan");
            }
        }
    }

    #[test]
    fn the_upstream_fallback_comes_after_the_own_seeds_and_ladder() {
        std::env::remove_var("AETHER_TEAM");
        let st = ScanMode::Balanced.strategy();
        let candidates = build_candidates(&st, MASQUE_PORTS, IpScan::V4);
        let seeds: Vec<Ipv4Addr> = MASQUE_SEEDS.iter().filter_map(|s| s.parse().ok()).collect();
        // The own seeds still lead, in their own order, on the primary port.
        for (i, seed) in seeds.iter().enumerate() {
            assert_eq!(candidates[i], (IpAddr::V4(*seed), 443));
        }
        // Every upstream gateway is there on every port, after the seed ladder.
        let head = seeds.len() * MASQUE_PORTS.len();
        for s in MASQUE_UPSTREAM_FALLBACK_V4 {
            let a: Ipv4Addr = s.parse().unwrap();
            for &port in MASQUE_PORTS {
                let at = candidates.iter().position(|c| *c == (IpAddr::V4(a), port));
                assert!(at.is_some(), "{a}:{port} missing");
                if !seeds.contains(&a) {
                    assert!(at.unwrap() >= head, "{a}:{port} jumped the seed ladder");
                }
            }
        }
        assert_eq!(MASQUE_UPSTREAM_FALLBACK_V4.len(), 297);
    }

    #[test]
    fn warp_ipv6_gateway_and_range_lead_the_ipv6_lists() {
        assert_eq!(MASQUE_SEEDS_V6.first(), Some(&"2606:4700:103::1"));
        assert_eq!(MASQUE_CIDRS_V6.first(), Some(&"2606:4700:103::/48"));
        for kept in ["2606:4700:d0::/48", "2606:4700:102::/48", "2606:4700:d1::/48"] {
            assert!(MASQUE_CIDRS_V6.contains(&kept));
        }
    }

    #[test]
    fn without_a_team_the_range_order_is_left_alone() {
        std::env::remove_var("AETHER_TEAM");
        assert_eq!(
            prioritize(MASQUE_CIDRS_V4, MASQUE_ZT_CIDRS_V4),
            MASQUE_CIDRS_V4.to_vec()
        );
    }

    #[test]
    fn prioritize_moves_the_wanted_entries_to_the_front_without_losing_any() {
        let all = ["a", "b", "c", "d"];
        let out = {
            let mut out: Vec<&'static str> = vec!["c"];
            for entry in all {
                if !out.contains(&entry) {
                    out.push(entry);
                }
            }
            out
        };
        assert_eq!(out, vec!["c", "a", "b", "d"]);
        assert_eq!(out.len(), all.len());
    }

    #[test]
    fn the_documented_masque_fallback_ports_are_all_covered() {
        for port in [443u16, 500, 1701, 4443, 4500, 8443, 8095] {
            assert!(
                MASQUE_PORTS.contains(&port),
                "documented fallback port {port} should be scanned"
            );
        }
    }

    async fn quic_answers(peer: SocketAddr, timeout: Duration) -> Option<Duration> {
        let bind = if peer.is_ipv4() { "0.0.0.0:0" } else { "[::]:0" };
        let sock = tokio::net::UdpSocket::bind(bind).await.ok()?;
        crate::platform::protect_socket(&sock).ok()?;
        sock.connect(peer).await.ok()?;
        let local = sock.local_addr().ok()?;

        let mut config = quiche::Config::new(quiche::PROTOCOL_VERSION).ok()?;
        config.set_application_protos(&[b"h3"]).ok()?;
        config.verify_peer(false);
        config.set_max_idle_timeout(timeout.as_millis() as u64);
        config.set_initial_max_data(1_000_000);
        config.set_initial_max_stream_data_bidi_local(100_000);
        config.set_initial_max_streams_bidi(4);

        let mut scid = [0u8; 16];
        rand::thread_rng().fill(&mut scid[..]);
        let scid = quiche::ConnectionId::from_ref(&scid);

        let sni = crate::consts::CONNECT_SNI;
        let mut conn = quiche::connect(Some(sni), &scid, local, peer, &mut config).ok()?;

        let mut out = [0u8; 1350];
        let (written, _) = conn.send(&mut out).ok()?;

        let started = Instant::now();
        sock.send(&out[..written]).await.ok()?;

        let mut buf = [0u8; 1500];
        match tokio::time::timeout(timeout, sock.recv(&mut buf)).await {
            Ok(Ok(read)) if read > 0 => Some(started.elapsed()),
            _ => None,
        }
    }

    async fn tcp_answers(peer: SocketAddr, timeout: Duration) -> Option<Duration> {
        let started = Instant::now();
        match tokio::time::timeout(timeout, tokio::net::TcpStream::connect(peer)).await {
            Ok(Ok(_)) => Some(started.elapsed()),
            _ => None,
        }
    }

    async fn first_answer(
        targets: &[SocketAddr],
        timeout: Duration,
        attempts: u32,
        udp: bool,
    ) -> Option<(SocketAddr, Duration)> {
        for _ in 0..attempts {
            let probes = targets.iter().copied().map(|peer| async move {
                let rtt = match udp {
                    true => quic_answers(peer, timeout).await,
                    false => tcp_answers(peer, timeout).await,
                };
                (peer, rtt)
            });

            let results: Vec<(SocketAddr, Option<Duration>)> = futures::stream::iter(probes)
                .buffer_unordered(targets.len().max(1))
                .collect()
                .await;

            if let Some((peer, Some(rtt))) = results.into_iter().find(|(_, rtt)| rtt.is_some()) {
                return Some((peer, rtt));
            }
        }
        None
    }

    fn hosts_of(cidr: &str, tails: &[u8]) -> Vec<Ipv4Addr> {
        let base: Ipv4Addr = cidr.split('/').next().unwrap().parse().expect("cidr base");
        let octets = base.octets();
        tails
            .iter()
            .map(|tail| Ipv4Addr::new(octets[0], octets[1], octets[2], *tail))
            .collect()
    }

    #[tokio::test(flavor = "multi_thread")]
    #[ignore = "probes the live cloudflare edge from this network to see which masque ranges answer"]
    async fn report_which_masque_ranges_answer_on_this_network() {
        const TAILS: &[u8] = &[1, 2, 3];

        let timeout = Duration::from_millis(
            std::env::var("AETHER_PROBE_TIMEOUT_MS")
                .ok()
                .and_then(|raw| raw.trim().parse::<u64>().ok())
                .filter(|ms| *ms > 0)
                .unwrap_or(10_000),
        );

        let attempts = std::env::var("AETHER_PROBE_ATTEMPTS")
            .ok()
            .and_then(|raw| raw.trim().parse::<u32>().ok())
            .filter(|n| *n > 0)
            .unwrap_or(2);

        let ports: Vec<u16> = match std::env::var("AETHER_PROBE_PORTS") {
            Ok(raw) => raw
                .split(',')
                .filter_map(|p| p.trim().parse::<u16>().ok())
                .collect(),
            Err(_) => vec![443],
        };
        let ports = if ports.is_empty() { vec![443] } else { ports };

        println!();
        println!("probing the masque ranges from this network");
        println!("  udp timeout {timeout:?}, {attempts} attempt(s), hosts {TAILS:?}");
        println!("  udp ports {ports:?}");
        println!("  override: AETHER_PROBE_TIMEOUT_MS, AETHER_PROBE_ATTEMPTS, AETHER_PROBE_PORTS");
        println!();

        let control: Vec<SocketAddr> = vec![
            "1.1.1.1:443".parse().unwrap(),
            "8.8.8.8:443".parse().unwrap(),
        ];

        let control_quic = first_answer(&control, timeout, attempts, true).await;
        let control_tcp = first_answer(&control, timeout, attempts, false).await;

        println!("control targets (public resolvers, not cloudflare warp edges)");
        match control_quic {
            Some((peer, rtt)) => println!("  quic/udp 443 works: {peer} in {}ms", rtt.as_millis()),
            None => println!("  quic/udp 443 got no answer at all"),
        }
        match control_tcp {
            Some((peer, rtt)) => println!("  tcp 443 works:      {peer} in {}ms", rtt.as_millis()),
            None => println!("  tcp 443 got no answer at all"),
        }
        println!();

        let mut udp_ok = Vec::new();
        let mut tcp_only = Vec::new();
        let mut silent = Vec::new();

        for cidr in MASQUE_CIDRS_V4 {
            let note = if MASQUE_DOCUMENTED_CIDRS_V4.contains(cidr) {
                " [documented]"
            } else if MASQUE_DOH_CIDRS_V4.contains(cidr) {
                " [dns-over-https]"
            } else {
                ""
            };

            let hosts = hosts_of(cidr, TAILS);

            let mut udp_hit: Option<(SocketAddr, Duration)> = None;
            for port in &ports {
                let targets: Vec<SocketAddr> = hosts
                    .iter()
                    .map(|ip| SocketAddr::new(IpAddr::V4(*ip), *port))
                    .collect();
                udp_hit = first_answer(&targets, timeout, attempts, true).await;
                if udp_hit.is_some() {
                    break;
                }
            }

            let tcp_targets: Vec<SocketAddr> = hosts
                .iter()
                .map(|ip| SocketAddr::new(IpAddr::V4(*ip), 443))
                .collect();
            let tcp_hit = first_answer(&tcp_targets, timeout, attempts, false).await;

            match (udp_hit, tcp_hit) {
                (Some((peer, rtt)), _) => {
                    println!("  UDP OK    {cidr}{note}  {peer} in {}ms", rtt.as_millis());
                    udp_ok.push(*cidr);
                }
                (None, Some((peer, rtt))) => {
                    println!(
                        "  TCP ONLY  {cidr}{note}  {peer} in {}ms, udp stayed silent",
                        rtt.as_millis()
                    );
                    tcp_only.push(*cidr);
                }
                (None, None) => {
                    println!("  SILENT    {cidr}{note}");
                    silent.push(*cidr);
                }
            }
        }

        println!();
        println!("masque over quic works on ({}):", udp_ok.len());
        for cidr in &udp_ok {
            println!("  {cidr}");
        }
        println!();
        println!("reachable over tcp only ({}):", tcp_only.len());
        for cidr in &tcp_only {
            println!("  {cidr}");
        }
        println!();
        println!("no answer on either ({}):", silent.len());
        for cidr in &silent {
            println!("  {cidr}");
        }

        println!();
        println!("verdict");
        if !udp_ok.is_empty() {
            println!("  put these ranges first in MASQUE_CIDRS_V4: {udp_ok:?}");
        } else if control_quic.is_none() {
            println!("  this network answers no quic at all, not even a public resolver,");
            println!("  so udp 443 is blocked here rather than these ranges being blocked.");
            println!("  reordering MASQUE_CIDRS_V4 cannot help; masque needs its http/2");
            println!("  fallback over tcp 443 (--masque-http2) on this network.");
        } else {
            println!("  quic works to other hosts but every warp range stayed silent,");
            println!("  so these ranges really are filtered here.");
            if !tcp_only.is_empty() {
                println!("  the tcp-only ranges above can still carry masque over http/2.");
            }
        }
        println!();
    }

    #[test]
    fn every_masque_prefix_and_seed_parses() {
        for entry in MASQUE_CIDRS_V4 {
            let (addr, bits) = entry.split_once('/').expect("cidr");
            assert!(addr.parse::<Ipv4Addr>().is_ok(), "{entry}");
            assert!(bits.parse::<u8>().is_ok(), "{entry}");
        }
        for entry in MASQUE_CIDRS_V6 {
            let (addr, bits) = entry.split_once('/').expect("cidr");
            assert!(addr.parse::<Ipv6Addr>().is_ok(), "{entry}");
            assert!(bits.parse::<u8>().is_ok(), "{entry}");
        }
        for seed in MASQUE_SEEDS {
            assert!(seed.parse::<Ipv4Addr>().is_ok(), "{seed}");
        }
        for seed in MASQUE_SEEDS_V6 {
            assert!(seed.parse::<Ipv6Addr>().is_ok(), "{seed}");
        }
    }
}
